def display_main_menu():
    print("display_main_menu")

def get_user_input():
    print("get_user_input")

def calc_average():
    print("calc_average")

def find_min_max(temperature_values_list):
    print("find_min_max")

def sort_temperature(temperature_values_list):
    print("sort_temperature")

def calc_median_temperature(temperature_values_list):
    print("calc_median_temperature")


     
